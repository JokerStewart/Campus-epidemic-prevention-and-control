package com.entity.view;

import com.entity.QiuzhutongdaoEntity;

import com.baomidou.mybatisplus.annotations.TableName;
import org.apache.commons.beanutils.BeanUtils;
import java.lang.reflect.InvocationTargetException;

import java.io.Serializable;
 

/**
 * 求助通道
 * 后端返回视图实体辅助类   
 * （通常后端关联的表或者自定义的字段需要返回使用）
 * @author 
 * @email 
 * @date 2022-08-04 17:56:31
 */
@TableName("qiuzhutongdao")
public class QiuzhutongdaoView  extends QiuzhutongdaoEntity implements Serializable {
	private static final long serialVersionUID = 1L;

	public QiuzhutongdaoView(){
	}
 
 	public QiuzhutongdaoView(QiuzhutongdaoEntity qiuzhutongdaoEntity){
 	try {
			BeanUtils.copyProperties(this, qiuzhutongdaoEntity);
		} catch (IllegalAccessException | InvocationTargetException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
 		
	}
}
