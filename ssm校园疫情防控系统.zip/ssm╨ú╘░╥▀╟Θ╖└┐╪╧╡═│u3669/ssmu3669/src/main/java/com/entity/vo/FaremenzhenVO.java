package com.entity.vo;

import com.entity.FaremenzhenEntity;

import com.baomidou.mybatisplus.annotations.TableName;
import com.fasterxml.jackson.annotation.JsonFormat;
import java.util.Date;
import org.springframework.format.annotation.DateTimeFormat;

import java.io.Serializable;
 

/**
 * 发热门诊
 * 手机端接口返回实体辅助类 
 * （主要作用去除一些不必要的字段）
 * @author 
 * @email 
 * @date 2022-08-04 17:56:31
 */
public class FaremenzhenVO  implements Serializable {
	private static final long serialVersionUID = 1L;

	 			
	/**
	 * 门诊图片
	 */
	
	private String menzhentupian;
		
	/**
	 * 门诊链接
	 */
	
	private String menzhenlianjie;
		
	/**
	 * 注意事项
	 */
	
	private String zhuyishixiang;
		
	/**
	 * 门诊介绍
	 */
	
	private String menzhenjieshao;
				
	
	/**
	 * 设置：门诊图片
	 */
	 
	public void setMenzhentupian(String menzhentupian) {
		this.menzhentupian = menzhentupian;
	}
	
	/**
	 * 获取：门诊图片
	 */
	public String getMenzhentupian() {
		return menzhentupian;
	}
				
	
	/**
	 * 设置：门诊链接
	 */
	 
	public void setMenzhenlianjie(String menzhenlianjie) {
		this.menzhenlianjie = menzhenlianjie;
	}
	
	/**
	 * 获取：门诊链接
	 */
	public String getMenzhenlianjie() {
		return menzhenlianjie;
	}
				
	
	/**
	 * 设置：注意事项
	 */
	 
	public void setZhuyishixiang(String zhuyishixiang) {
		this.zhuyishixiang = zhuyishixiang;
	}
	
	/**
	 * 获取：注意事项
	 */
	public String getZhuyishixiang() {
		return zhuyishixiang;
	}
				
	
	/**
	 * 设置：门诊介绍
	 */
	 
	public void setMenzhenjieshao(String menzhenjieshao) {
		this.menzhenjieshao = menzhenjieshao;
	}
	
	/**
	 * 获取：门诊介绍
	 */
	public String getMenzhenjieshao() {
		return menzhenjieshao;
	}
			
}
