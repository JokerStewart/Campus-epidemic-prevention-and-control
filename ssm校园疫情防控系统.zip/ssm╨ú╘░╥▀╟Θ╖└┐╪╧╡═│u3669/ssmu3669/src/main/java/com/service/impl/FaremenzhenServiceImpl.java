package com.service.impl;

import org.springframework.stereotype.Service;
import java.util.Map;
import java.util.List;

import com.baomidou.mybatisplus.mapper.Wrapper;
import com.baomidou.mybatisplus.mapper.EntityWrapper;
import com.baomidou.mybatisplus.plugins.Page;
import com.baomidou.mybatisplus.service.impl.ServiceImpl;
import com.utils.PageUtils;
import com.utils.Query;


import com.dao.FaremenzhenDao;
import com.entity.FaremenzhenEntity;
import com.service.FaremenzhenService;
import com.entity.vo.FaremenzhenVO;
import com.entity.view.FaremenzhenView;

@Service("faremenzhenService")
public class FaremenzhenServiceImpl extends ServiceImpl<FaremenzhenDao, FaremenzhenEntity> implements FaremenzhenService {
	

    @Override
    public PageUtils queryPage(Map<String, Object> params) {
        Page<FaremenzhenEntity> page = this.selectPage(
                new Query<FaremenzhenEntity>(params).getPage(),
                new EntityWrapper<FaremenzhenEntity>()
        );
        return new PageUtils(page);
    }
    
    @Override
	public PageUtils queryPage(Map<String, Object> params, Wrapper<FaremenzhenEntity> wrapper) {
		  Page<FaremenzhenView> page =new Query<FaremenzhenView>(params).getPage();
	        page.setRecords(baseMapper.selectListView(page,wrapper));
	    	PageUtils pageUtil = new PageUtils(page);
	    	return pageUtil;
 	}
    
    @Override
	public List<FaremenzhenVO> selectListVO(Wrapper<FaremenzhenEntity> wrapper) {
 		return baseMapper.selectListVO(wrapper);
	}
	
	@Override
	public FaremenzhenVO selectVO(Wrapper<FaremenzhenEntity> wrapper) {
 		return baseMapper.selectVO(wrapper);
	}
	
	@Override
	public List<FaremenzhenView> selectListView(Wrapper<FaremenzhenEntity> wrapper) {
		return baseMapper.selectListView(wrapper);
	}

	@Override
	public FaremenzhenView selectView(Wrapper<FaremenzhenEntity> wrapper) {
		return baseMapper.selectView(wrapper);
	}


}
