package com.service;

import com.baomidou.mybatisplus.mapper.Wrapper;
import com.baomidou.mybatisplus.service.IService;
import com.utils.PageUtils;
import com.entity.FaremenzhenEntity;
import java.util.List;
import java.util.Map;
import com.entity.vo.FaremenzhenVO;
import org.apache.ibatis.annotations.Param;
import com.entity.view.FaremenzhenView;


/**
 * 发热门诊
 *
 * @author 
 * @email 
 * @date 2022-08-04 17:56:31
 */
public interface FaremenzhenService extends IService<FaremenzhenEntity> {

    PageUtils queryPage(Map<String, Object> params);
    
   	List<FaremenzhenVO> selectListVO(Wrapper<FaremenzhenEntity> wrapper);
   	
   	FaremenzhenVO selectVO(@Param("ew") Wrapper<FaremenzhenEntity> wrapper);
   	
   	List<FaremenzhenView> selectListView(Wrapper<FaremenzhenEntity> wrapper);
   	
   	FaremenzhenView selectView(@Param("ew") Wrapper<FaremenzhenEntity> wrapper);
   	
   	PageUtils queryPage(Map<String, Object> params,Wrapper<FaremenzhenEntity> wrapper);
   	

}

