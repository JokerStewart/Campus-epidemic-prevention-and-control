package com.service.impl;

import org.springframework.stereotype.Service;
import java.util.Map;
import java.util.List;

import com.baomidou.mybatisplus.mapper.Wrapper;
import com.baomidou.mybatisplus.mapper.EntityWrapper;
import com.baomidou.mybatisplus.plugins.Page;
import com.baomidou.mybatisplus.service.impl.ServiceImpl;
import com.utils.PageUtils;
import com.utils.Query;


import com.dao.QiuzhutongdaoDao;
import com.entity.QiuzhutongdaoEntity;
import com.service.QiuzhutongdaoService;
import com.entity.vo.QiuzhutongdaoVO;
import com.entity.view.QiuzhutongdaoView;

@Service("qiuzhutongdaoService")
public class QiuzhutongdaoServiceImpl extends ServiceImpl<QiuzhutongdaoDao, QiuzhutongdaoEntity> implements QiuzhutongdaoService {
	

    @Override
    public PageUtils queryPage(Map<String, Object> params) {
        Page<QiuzhutongdaoEntity> page = this.selectPage(
                new Query<QiuzhutongdaoEntity>(params).getPage(),
                new EntityWrapper<QiuzhutongdaoEntity>()
        );
        return new PageUtils(page);
    }
    
    @Override
	public PageUtils queryPage(Map<String, Object> params, Wrapper<QiuzhutongdaoEntity> wrapper) {
		  Page<QiuzhutongdaoView> page =new Query<QiuzhutongdaoView>(params).getPage();
	        page.setRecords(baseMapper.selectListView(page,wrapper));
	    	PageUtils pageUtil = new PageUtils(page);
	    	return pageUtil;
 	}
    
    @Override
	public List<QiuzhutongdaoVO> selectListVO(Wrapper<QiuzhutongdaoEntity> wrapper) {
 		return baseMapper.selectListVO(wrapper);
	}
	
	@Override
	public QiuzhutongdaoVO selectVO(Wrapper<QiuzhutongdaoEntity> wrapper) {
 		return baseMapper.selectVO(wrapper);
	}
	
	@Override
	public List<QiuzhutongdaoView> selectListView(Wrapper<QiuzhutongdaoEntity> wrapper) {
		return baseMapper.selectListView(wrapper);
	}

	@Override
	public QiuzhutongdaoView selectView(Wrapper<QiuzhutongdaoEntity> wrapper) {
		return baseMapper.selectView(wrapper);
	}


}
