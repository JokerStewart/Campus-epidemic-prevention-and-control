package com.dao;

import com.entity.GelirenyuanEntity;
import com.baomidou.mybatisplus.mapper.BaseMapper;
import java.util.List;
import java.util.Map;
import com.baomidou.mybatisplus.mapper.Wrapper;
import com.baomidou.mybatisplus.plugins.pagination.Pagination;

import org.apache.ibatis.annotations.Param;
import com.entity.vo.GelirenyuanVO;
import com.entity.view.GelirenyuanView;


/**
 * 隔离人员
 * 
 * @author 
 * @email 
 * @date 2022-08-04 17:56:31
 */
public interface GelirenyuanDao extends BaseMapper<GelirenyuanEntity> {
	
	List<GelirenyuanVO> selectListVO(@Param("ew") Wrapper<GelirenyuanEntity> wrapper);
	
	GelirenyuanVO selectVO(@Param("ew") Wrapper<GelirenyuanEntity> wrapper);
	
	List<GelirenyuanView> selectListView(@Param("ew") Wrapper<GelirenyuanEntity> wrapper);

	List<GelirenyuanView> selectListView(Pagination page,@Param("ew") Wrapper<GelirenyuanEntity> wrapper);
	
	GelirenyuanView selectView(@Param("ew") Wrapper<GelirenyuanEntity> wrapper);
	

}
