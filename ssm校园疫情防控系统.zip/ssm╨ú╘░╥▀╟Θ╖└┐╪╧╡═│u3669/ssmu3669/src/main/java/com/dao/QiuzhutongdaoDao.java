package com.dao;

import com.entity.QiuzhutongdaoEntity;
import com.baomidou.mybatisplus.mapper.BaseMapper;
import java.util.List;
import java.util.Map;
import com.baomidou.mybatisplus.mapper.Wrapper;
import com.baomidou.mybatisplus.plugins.pagination.Pagination;

import org.apache.ibatis.annotations.Param;
import com.entity.vo.QiuzhutongdaoVO;
import com.entity.view.QiuzhutongdaoView;


/**
 * 求助通道
 * 
 * @author 
 * @email 
 * @date 2022-08-04 17:56:31
 */
public interface QiuzhutongdaoDao extends BaseMapper<QiuzhutongdaoEntity> {
	
	List<QiuzhutongdaoVO> selectListVO(@Param("ew") Wrapper<QiuzhutongdaoEntity> wrapper);
	
	QiuzhutongdaoVO selectVO(@Param("ew") Wrapper<QiuzhutongdaoEntity> wrapper);
	
	List<QiuzhutongdaoView> selectListView(@Param("ew") Wrapper<QiuzhutongdaoEntity> wrapper);

	List<QiuzhutongdaoView> selectListView(Pagination page,@Param("ew") Wrapper<QiuzhutongdaoEntity> wrapper);
	
	QiuzhutongdaoView selectView(@Param("ew") Wrapper<QiuzhutongdaoEntity> wrapper);
	

}
