package com.dao;

import com.entity.FaremenzhenEntity;
import com.baomidou.mybatisplus.mapper.BaseMapper;
import java.util.List;
import java.util.Map;
import com.baomidou.mybatisplus.mapper.Wrapper;
import com.baomidou.mybatisplus.plugins.pagination.Pagination;

import org.apache.ibatis.annotations.Param;
import com.entity.vo.FaremenzhenVO;
import com.entity.view.FaremenzhenView;


/**
 * 发热门诊
 * 
 * @author 
 * @email 
 * @date 2022-08-04 17:56:31
 */
public interface FaremenzhenDao extends BaseMapper<FaremenzhenEntity> {
	
	List<FaremenzhenVO> selectListVO(@Param("ew") Wrapper<FaremenzhenEntity> wrapper);
	
	FaremenzhenVO selectVO(@Param("ew") Wrapper<FaremenzhenEntity> wrapper);
	
	List<FaremenzhenView> selectListView(@Param("ew") Wrapper<FaremenzhenEntity> wrapper);

	List<FaremenzhenView> selectListView(Pagination page,@Param("ew") Wrapper<FaremenzhenEntity> wrapper);
	
	FaremenzhenView selectView(@Param("ew") Wrapper<FaremenzhenEntity> wrapper);
	

}
